host = 'localhost'
port = 27017
db = 'taobao'